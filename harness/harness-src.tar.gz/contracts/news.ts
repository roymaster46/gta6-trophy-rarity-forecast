// news.make.fun's contract: the daily front page built from the WINNING entry of make.fun's daily bounty "Sum up
// <D Month>'s world news in one image" (server/releases/templates/news-image.ts, slug news-image-YYYYMMDD). The pipeline
// reads the winner's image into a NewsEdition, the store keeps it (server/news/store.ts; news_edition and news_story,
// server/db/schema.ts), and the server and the web app both render it, so every shape, helper and sentence they share
// lives here. A leaf like contracts/feedback.ts: no Node APIs, no DOM and no import from server/ (the web app imports it).
//
//   NEWS_SCHEMA                 the edition document's format, 'news-edition/1'
//   NEWS_REGIONS                the seven regions in reading order, each with its label; NEWS_REGION_IDS their ids
//   NEWS_TIERS                  a story's place on the page: lead (the top row), card (the grid), brief (the list)
//   NEWS_EDITION_STATUSES       a built edition's status: provisional (voting still open) or final
//   NEWS_ROW_STATUSES           news_edition.status: pending, provisional, final, failed, withheld (the pipeline's states)
//   NewsLink … NewsEdition      the edition document (zod schemas; each type is the schema's z.infer, same name)
//   NewsEditionView             GET one day: the edition with its neighbours and its formats' URLs
//   NewsDaysResponse            GET the days: every content-ready day, newest first, and the open bounty
//   NewsSearchResponse          GET search: matching stories across every day
//   isNewsHost, mainOriginForNewsHost, newsOriginForMain
//                               the news host (first DNS label 'news') and the main site's origin, each from the other
//   dayTitle, dayShortLabel, isNewsDay, newsDayOf
//                               day words ('Wednesday 18 November 2026', 'Tue 17 Nov'), a real day, an instant's day
//   newsBountySlug, dayOfNewsBountySlug
//                               the day's bounty slug (news-image-YYYYMMDD) and back
//   storyAnchor, newsDayPath, newsEditionUrls, newsStoryUrl
//                               paths on the news host: '/<day>' (.json, .md, .txt) and '#story-<n>'
//   profileUrl, regionCounts, regionLabel
//   NEWS_LIMITS, clipNewsText   the most characters each text field holds (and the most stories, links and outlets),
//                               and a text cut at a word boundary to fit one (the build clips the model's words to them)
//   isDeletedHandle, creditByline
//                               a deleted account's tombstone handle, and the credit's entrant as every renderer names
//                               them ('@handle' and the profile; a deleted account NEWS_COPY.formerPlayer, no link)
//   formatCount                 a whole number with thousands separators, as en-US writes it ('19,452')
//   NEWS_COPY                   the words the web page and the server's crawl body both print (they must match), a
//                               news-search fallback link's name (newsSearch) and the credit's agents line
//                               (agentsWorked: '19,452 AI agents worked on this') among them
//
// Days are UTC calendar days, 'YYYY-MM-DD'. Every instant is ISO 8601 (zod's iso datetime, an offset allowed).

import { z } from 'zod';

/** The edition document's format: a NewsEdition's `schema`. */
export const NEWS_SCHEMA = 'news-edition/1';

/** The regions in the order the page prints them, each with its label. */
export const NEWS_REGIONS = [
  { id: 'europe', label: 'Europe' },
  { id: 'middle-east', label: 'Middle East' },
  { id: 'asia', label: 'Asia' },
  { id: 'africa', label: 'Africa' },
  { id: 'americas', label: 'Americas' },
  { id: 'oceania', label: 'Oceania' },
  { id: 'world', label: 'World' },
] as const;
export const NEWS_REGION_IDS = ['europe', 'middle-east', 'asia', 'africa', 'americas', 'oceania', 'world'] as const;
export const NewsRegionId = z.enum(NEWS_REGION_IDS);
export type NewsRegionId = z.infer<typeof NewsRegionId>;

/** lead: the top row's big stories; card: the grid; brief: the one-line "Also on" list. */
export const NEWS_TIERS = ['lead', 'card', 'brief'] as const;
export const NewsTier = z.enum(NEWS_TIERS);
export type NewsTier = z.infer<typeof NewsTier>;

/** A built edition: provisional while the bounty's voting is still open (its winner may change), final once resolved. */
export const NEWS_EDITION_STATUSES = ['provisional', 'final'] as const;
export const NewsEditionStatus = z.enum(NEWS_EDITION_STATUSES);
export type NewsEditionStatus = z.infer<typeof NewsEditionStatus>;

/**
 * news_edition.status, the pipeline's: pending (a winner's image is known, its edition not yet built), provisional and
 * final (built, as NEWS_EDITION_STATUSES), failed (the last build failed with none built before it), withheld (no front
 * page: its winning entry was taken down or is gone, or its bounty was cancelled; no content, the row kept for the
 * audit with why in its error, and never built again on its own).
 */
export const NEWS_ROW_STATUSES = ['pending', 'provisional', 'final', 'failed', 'withheld'] as const;
export type NewsRowStatus = (typeof NEWS_ROW_STATUSES)[number];

/**
 * Where a story link came from: gdelt (a GDELT article), bing (an article Bing News's RSS search named: its publisher's own
 * URL, never Bing's or Google's redirect), model (the reader model named it), search (a news-search URL, no article found).
 */
export const NEWS_LINK_VIAS = ['gdelt', 'bing', 'model', 'search'] as const;

export const NEWS_DAY_RE = /^\d{4}-\d{2}-\d{2}$/;
const SHA256_RE = /^[0-9a-f]{64}$/;

const day = z.string().refine((s) => isNewsDay(s), 'a real UTC day, YYYY-MM-DD');
const instant = z.iso.datetime({ offset: true });
const sha256 = z.string().regex(SHA256_RE, 'lowercase hex sha256');
const words = z.string().trim().min(1);

/**
 * The most characters each of an edition's text fields holds, and the most stories, links and outlets: about three
 * times the longest the real 18 November edition holds (tests/fixtures/news/2026-11-18.real.json: a 64-character
 * headline, a 143-character summary, 40 stories), so no real front page meets one and a runaway model answer never
 * reaches a page. The build clips the model's words to them (clipNewsText, server/news/build.ts assembleNewsEdition);
 * NewsEdition refuses anything longer.
 */
export const NEWS_LIMITS = {
  stories: 150,
  headline: 200,
  summary: 600,
  section: 80,
  place: 120,
  /** An outlet's name, credited or a link's. */
  outlet: 80,
  outlets: 20,
  links: 20,
  linkTitle: 300,
  /** A host name's most (RFC 1035). */
  domain: 253,
  url: 2048,
  alt: 300,
  kicker: 200,
  title: 120,
  handle: 100,
  entryTitle: 200,
  id: 100,
  model: 200,
} as const;

/** `max` characters of text at most: `s` itself when it fits, else cut at its last space in reach with an ellipsis. */
export function clipNewsText(s: string, max: number): string {
  const t = s.trim();
  if (t.length <= max) return t;
  let cut = t.slice(0, Math.max(0, max - 1));
  // Never half a surrogate pair.
  if (/[\uD800-\uDBFF]$/.test(cut)) cut = cut.slice(0, -1);
  const space = cut.lastIndexOf(' ');
  if (space >= max / 2) cut = cut.slice(0, space);
  return `${cut.trimEnd()}…`;
}

const httpUrl = z.url({ protocol: /^https?$/ }).max(NEWS_LIMITS.url);

/** words of at most `max` characters. */
const wordsMax = (max: number) => words.max(max);

/** One source link of a story. */
export const NewsLink = z.object({
  url: httpUrl,
  /** The outlet's name, as a reader knows it ('Reuters'). */
  outlet: wordsMax(NEWS_LIMITS.outlet),
  /** The URL's host without 'www.' ('reuters.com'). */
  domain: wordsMax(NEWS_LIMITS.domain),
  title: wordsMax(NEWS_LIMITS.linkTitle).optional(),
  publishedAt: instant.optional(),
  via: z.enum(NEWS_LINK_VIAS),
});
export type NewsLink = z.infer<typeof NewsLink>;

/** A story's picture, cut from the winner's image and kept in the blob store under sha256. */
export const NewsIllustration = z.object({
  sha256,
  width: z.number().int().positive(),
  height: z.number().int().positive(),
  alt: wordsMax(NEWS_LIMITS.alt),
});
export type NewsIllustration = z.infer<typeof NewsIllustration>;

export const NewsGeo = z.object({ lat: z.number().min(-90).max(90), lon: z.number().min(-180).max(180) });
export type NewsGeo = z.infer<typeof NewsGeo>;

/** One story on the page. */
export const NewsStory = z.object({
  /** The number the image prints beside the story, else its place in reading order (1-based); unique in an edition. */
  n: z.number().int().positive(),
  tier: NewsTier,
  region: NewsRegionId,
  /** The section tag as printed ('APEC SUMMIT'), without its region. */
  section: wordsMax(NEWS_LIMITS.section).optional(),
  /** Where it happened, a place name ('Manila'). */
  place: wordsMax(NEWS_LIMITS.place).optional(),
  headline: wordsMax(NEWS_LIMITS.headline),
  summary: wordsMax(NEWS_LIMITS.summary).optional(),
  /** The outlets the image credits, as printed (['NPR', 'Reuters']); empty when it credits none. */
  outlets: z.array(wordsMax(NEWS_LIMITS.outlet)).max(NEWS_LIMITS.outlets),
  links: z.array(NewsLink).max(NEWS_LIMITS.links),
  illustration: NewsIllustration.optional(),
  geo: NewsGeo.optional(),
});
export type NewsStory = z.infer<typeof NewsStory>;

/** Who made the front page: the winning entry and its entrant, and how many entries the bounty drew. */
export const NewsCredit = z.object({
  handle: wordsMax(NEWS_LIMITS.handle),
  profileUrl: httpUrl,
  entryTitle: wordsMax(NEWS_LIMITS.entryTitle),
  submissionId: wordsMax(NEWS_LIMITS.id),
  bountySlug: wordsMax(NEWS_LIMITS.id),
  bountyUrl: httpUrl,
  imageUrl: httpUrl,
  /** The entry's win rate in the bounty's judging, in millionths (991000 = 99.1%). */
  winRateMicro: z.number().int().min(0).max(1_000_000).optional(),
  /**
   * The day's bounty's entries, the count its page on make.fun shows (the board's submissionCount for a signed-out
   * reader: server/news/store.ts newsEntryCount), printed under the byline as NEWS_COPY.agentsWorked. Stored at the
   * build and refreshed when the edition turns final; while it is provisional (the bounty still taking entries) every
   * read of it carries the count as it stands (server/news/store.ts getEdition).
   */
  entryCount: z.number().int().min(0),
});
export type NewsCredit = z.infer<typeof NewsCredit>;

export const NewsRegionCount = z.object({ id: NewsRegionId, count: z.number().int().min(0) });
export type NewsRegionCount = z.infer<typeof NewsRegionCount>;

export const NewsProvenance = z.object({
  /** The sha256 of the winning image the edition was read from. */
  artifactSha256: sha256,
  /** The model that read it. */
  model: wordsMax(NEWS_LIMITS.model),
  extractedAt: instant,
  /** When its stories' links were checked, if they were. */
  verifiedAt: instant.optional(),
});
export type NewsProvenance = z.infer<typeof NewsProvenance>;

/**
 * One day's front page. `stories` hold unique `n`s; `regions` is the region band as the image prints it (else
 * regionCounts(stories)), each region at most once.
 */
export const NewsEdition = z
  .object({
    schema: z.literal(NEWS_SCHEMA),
    day,
    status: NewsEditionStatus,
    /** The day in words, dayTitle(day): 'Wednesday 18 November 2026'. */
    title: wordsMax(NEWS_LIMITS.title),
    kicker: wordsMax(NEWS_LIMITS.kicker).optional(),
    stories: z.array(NewsStory).max(NEWS_LIMITS.stories),
    regions: z.array(NewsRegionCount),
    credit: NewsCredit,
    provenance: NewsProvenance,
    updatedAt: instant,
  })
  .superRefine((e, ctx) => {
    const seen = new Set<number>();
    e.stories.forEach((s, i) => {
      if (seen.has(s.n)) ctx.addIssue({ code: 'custom', path: ['stories', i, 'n'], message: `story number ${s.n} appears twice` });
      seen.add(s.n);
    });
    const regions = new Set<string>();
    e.regions.forEach((r, i) => {
      if (regions.has(r.id)) ctx.addIssue({ code: 'custom', path: ['regions', i, 'id'], message: `region ${r.id} appears twice` });
      regions.add(r.id);
    });
  });
export type NewsEdition = z.infer<typeof NewsEdition>;

// ---------------------------------------------------------------- API views

/** An edition's formats, absolute URLs on the news host. */
export const NewsEditionUrls = z.object({ html: httpUrl, json: httpUrl, md: httpUrl, txt: httpUrl });
export type NewsEditionUrls = z.infer<typeof NewsEditionUrls>;

/** GET one day: the edition, the content-ready days either side of it (null at an end) and its formats' URLs. */
export const NewsEditionView = z.intersection(
  NewsEdition,
  z.object({ prev: day.nullable(), next: day.nullable(), urls: NewsEditionUrls }),
);
export type NewsEditionView = z.infer<typeof NewsEditionView>;

export const NewsDaySummary = z.object({
  day,
  title: words,
  status: NewsEditionStatus,
  storyCount: z.number().int().min(0),
  winnerHandle: words,
});
export type NewsDaySummary = z.infer<typeof NewsDaySummary>;

/** GET the days: content-ready days, newest first, and the bounty now open for tomorrow's front page (null when none). */
export const NewsDaysResponse = z.object({
  days: z.array(NewsDaySummary),
  openBounty: z.object({ slug: words, url: httpUrl, deadline: instant }).nullable(),
});
export type NewsDaysResponse = z.infer<typeof NewsDaysResponse>;

/** One search hit: a story of a day, and its URL on the news host (the day's page at the story's anchor). */
export const NewsSearchResult = z.object({
  day,
  n: z.number().int().positive(),
  tier: NewsTier,
  region: NewsRegionId,
  headline: words,
  summary: words.optional(),
  url: httpUrl,
  links: z.array(NewsLink),
});
export type NewsSearchResult = z.infer<typeof NewsSearchResult>;

export const NewsSearchResponse = z.object({ q: z.string(), results: z.array(NewsSearchResult) });
export type NewsSearchResponse = z.infer<typeof NewsSearchResponse>;

// ---------------------------------------------------------------- helpers

const WEEKDAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'] as const;
const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'] as const;

/** A host's name without its port, lowercased: 'News.Make.fun:443' -> 'news.make.fun'. An IPv6 literal stays whole. */
function bareHost(host: string): string {
  const h = host.trim().toLowerCase();
  if (h.startsWith('[')) return h;
  const colon = h.lastIndexOf(':');
  return colon === -1 ? h : h.slice(0, colon);
}

/** Whether a hostname is a news host: its first DNS label is 'news' (news.make.fun, news.dev.make.fun, news.localhost). A port is ignored. */
export function isNewsHost(hostname: string): boolean {
  const labels = bareHost(hostname).split('.');
  return labels.length >= 2 && labels[0] === 'news' && labels.every((l) => l !== '');
}

/** 'https', 'https:' or 'https://' as 'https:'. */
function schemeOf(protocol: string): string {
  return `${protocol.replace(/:?\/*$/, '')}:`;
}

/**
 * The main site's origin for a news host: the host without its 'news.' (its port kept), under `protocol` ('https' or
 * 'https:'). news.dev.make.fun -> https://dev.make.fun. A host that is not a news host is answered as its own origin.
 */
export function mainOriginForNewsHost(host: string, protocol: string): string {
  const h = host.trim().toLowerCase();
  const main = isNewsHost(h) ? h.slice('news.'.length) : h;
  return `${schemeOf(protocol)}//${main}`;
}

/** The news origin for the main site's origin: https://make.fun -> https://news.make.fun. A news origin is answered unchanged. */
export function newsOriginForMain(origin: string): string {
  const u = new URL(origin);
  return isNewsHost(u.host) ? `${u.protocol}//${u.host}` : `${u.protocol}//news.${u.host}`;
}

/** The anchor of story `n` on its day's page: 'story-7'. */
export function storyAnchor(n: number): string {
  return `story-${n}`;
}

/** An edition's formats, as NewsEditionUrls names them. */
export const NEWS_FORMATS = ['html', 'json', 'md', 'txt'] as const;
export type NewsFormat = (typeof NEWS_FORMATS)[number];

/** A day's path on the news host: '/2026-11-18' for its page, '/2026-11-18.json' (.md, .txt) for its other formats. */
export function newsDayPath(day: string, format: NewsFormat = 'html'): string {
  dateOf(day);
  return format === 'html' ? `/${day}` : `/${day}.${format}`;
}

/** Every format's absolute URL of a day on the news origin (NewsEditionView.urls). */
export function newsEditionUrls(newsOrigin: string, day: string): NewsEditionUrls {
  const o = newsOrigin.replace(/\/+$/, '');
  return { html: `${o}${newsDayPath(day)}`, json: `${o}${newsDayPath(day, 'json')}`, md: `${o}${newsDayPath(day, 'md')}`, txt: `${o}${newsDayPath(day, 'txt')}` };
}

/** A story's URL: its day's page at its anchor ('https://news.make.fun/2026-11-18#story-7'). */
export function newsStoryUrl(newsOrigin: string, day: string, n: number): string {
  return `${newsOrigin.replace(/\/+$/, '')}${newsDayPath(day)}#${storyAnchor(n)}`;
}

/** Whether `s` is a real UTC calendar day written YYYY-MM-DD ('2026-02-30' is not). */
export function isNewsDay(s: unknown): s is string {
  if (typeof s !== 'string' || !NEWS_DAY_RE.test(s)) return false;
  const [y, m, d] = s.split('-').map(Number) as [number, number, number];
  const t = new Date(Date.UTC(y, m - 1, d));
  return t.getUTCFullYear() === y && t.getUTCMonth() === m - 1 && t.getUTCDate() === d;
}

function dateOf(day: string): Date {
  if (!isNewsDay(day)) throw new RangeError(`not a news day: ${JSON.stringify(day)}`);
  return new Date(`${day}T00:00:00Z`);
}

/** The day in words, in UTC: '2026-11-18' -> 'Wednesday 18 November 2026'. Throws a RangeError on anything but a news day. */
export function dayTitle(day: string): string {
  const d = dateOf(day);
  return `${WEEKDAYS[d.getUTCDay()]} ${d.getUTCDate()} ${MONTHS[d.getUTCMonth()]} ${d.getUTCFullYear()}`;
}

/** The day's short label, for the day arrows: '2026-11-17' -> 'Tue 17 Nov'. Throws a RangeError on anything but a news day. */
export function dayShortLabel(day: string): string {
  const d = dateOf(day);
  return `${WEEKDAYS[d.getUTCDay()]!.slice(0, 3)} ${d.getUTCDate()} ${MONTHS[d.getUTCMonth()]!.slice(0, 3)}`;
}

/** The news day an instant falls in (UTC): its 'YYYY-MM-DD'. */
export function newsDayOf(at: Date): string {
  return at.toISOString().slice(0, 10);
}

/** The daily bounty's slug for a day, as server/releases/templates/news-image.ts newsImageSlug: '2026-11-18' -> 'news-image-20261118'. */
export function newsBountySlug(day: string): string {
  dateOf(day);
  return `news-image-${day.replaceAll('-', '')}`;
}

/** The day a daily news bounty's slug covers, else null: 'news-image-20261118' -> '2026-11-18'. */
export function dayOfNewsBountySlug(slug: string): string | null {
  const m = /^news-image-(\d{4})(\d{2})(\d{2})$/.exec(slug);
  if (m === null) return null;
  const day = `${m[1]}-${m[2]}-${m[3]}`;
  return isNewsDay(day) ? day : null;
}

/** An entrant's public profile on the main site: `${mainOrigin}/u/${handle}` (src/routes/match.ts USER_PREFIX). */
export function profileUrl(mainOrigin: string, handle: string): string {
  return `${mainOrigin.replace(/\/+$/, '')}/u/${encodeURIComponent(handle)}`;
}

/**
 * The prefix of the handle a deleted account's tombstone takes (server/profile/handle.ts DELETED_HANDLE_PREFIX, restated:
 * this leaf imports nothing of server/; tests/unit/news-contract.test.ts holds the two equal).
 */
export const NEWS_DELETED_HANDLE_PREFIX = 'deleted-';

/** Whether a credit's handle is a deleted account's tombstone's (deleted-<hex>, server/profile/handle.ts deletedHandle). */
export function isDeletedHandle(handle: string): boolean {
  return handle.startsWith(NEWS_DELETED_HANDLE_PREFIX);
}

/**
 * The credit's entrant as every renderer names them (the page, the crawl body, the text formats, the feeds, the JSON-LD):
 * '@'+handle and their profile URL; a deleted account (isDeletedHandle) NEWS_COPY.formerPlayer and no link, as no page
 * names it.
 */
export function creditByline(credit: Pick<NewsCredit, 'handle' | 'profileUrl'>): { name: string; url: string | null } {
  return isDeletedHandle(credit.handle) ? { name: NEWS_COPY.formerPlayer, url: null } : { name: `@${credit.handle}`, url: credit.profileUrl };
}

/** A whole number with thousands separators, as en-US writes it: 19452 -> '19,452'. The same on every runtime (no Intl). */
export function formatCount(n: number): string {
  const t = String(Math.trunc(Math.abs(n))).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  return n < 0 ? `-${t}` : t;
}

/** How many stories each region holds, in NEWS_REGIONS order, regions with none left out. */
export function regionCounts(stories: readonly Pick<NewsStory, 'region'>[]): NewsRegionCount[] {
  const counts = new Map<NewsRegionId, number>();
  for (const s of stories) counts.set(s.region, (counts.get(s.region) ?? 0) + 1);
  return NEWS_REGION_IDS.filter((id) => counts.has(id)).map((id) => ({ id, count: counts.get(id)! }));
}

/** A region's label: 'middle-east' -> 'Middle East'. */
export function regionLabel(id: NewsRegionId): string {
  return NEWS_REGIONS.find((r) => r.id === id)!.label;
}

// ---------------------------------------------------------------- copy

/**
 * The words both the web page and the server's crawl body print (the public views must say the same): change one here,
 * never in a renderer.
 */
export const NEWS_COPY = {
  kicker: 'The day in world news',
  byline: 'Front page by',
  viewProfile: 'View profile',
  whereItHappened: 'Where it happened',
  alsoOn: 'Also on',
  provisional: 'Provisional: voting is still open',
  cta: "Make tomorrow's front page",
  stories: 'stories',
  regions: 'regions',
  formats: { rss: 'RSS', json: 'JSON', md: 'Markdown', llms: 'llms.txt' },
  searchPlaceholder: "Search every day's stories",
  /** A news-search fallback link's name (NewsLink via 'search': no article was found), wherever a story's sources are listed. */
  newsSearch: 'News search',
  /** A deleted account, as a credit names it (creditByline): no handle, no profile. */
  formerPlayer: 'a former make.fun player',
  /**
   * The line under the byline, linked to the day's bounty: its entries (NewsCredit.entryCount), the owner's words
   * (2026-11-19): '19,452 AI agents worked on this', '1 AI agent worked on this'.
   */
  agentsWorked: (n: number): string => `${formatCount(n)} AI ${n === 1 ? 'agent' : 'agents'} worked on this`,
} as const;
