// The k8s sandbox's recurring list reads (k8s.ts's header, Room on the node) asked of the API server in-process, not of
// a kubectl spawned for each. A grader reads the nodes and the pods bound to each (K8sSandbox.nodePodRooms), its live
// graders (runningGraders) and the sandbox pods its namespace holds (sandboxPodsHeld) every few seconds, idle or not.
// Measured on makefun-prod (2026-11-12): kubectl decodes every pod whole even for `-o name` (0.54 s of CPU for s18's
// 1.07 MB list, about 0.94 s for one room read), so those reads cost a grader about 0.135 cores idle, 17% of its CPU,
// and 0.47 cores a process while jobs wait for room. The same counts asked as a Table (`Accept:
// application/json;as=Table;g=meta.k8s.io;v=v1`, `includeObject=None`: one row of cells per object, 16 KB for s18) cost
// 1.3-1.6 ms each, with the same `list` verbs the Role and node-read.yaml grant already.
//
// apiListExec is a KubectlExec over the API server: it answers the argv shapes of those reads, `[-n <ns>] get
// pods|nodes [--all-namespaces] [-l <sel>] [--field-selector <sel>] -o name|json`, as kubectl would print them (`pod/<name>`
// lines from the Table's first cell; the API server's own JSON list), and hands every other argv to kubectl. A 403 is
// kubectl's `Error from server (Forbidden): <message>` (what K8sSandbox's refusal path reads); a call its budget or its
// signal cut is kubectl's cut (`error`), never sent again. A shed (HTTP 429, or any 5xx: the API server's Priority and
// Fairness rejecting a queued request, its own timeout, etcd's) is a cut too, never handed to kubectl: kubectl's full
// JSON list is the heavier ask of the same congested flow, and its client-go retries a 429 up to ten times itself. The
// shed opens a streak (said once, and once more when a list answers again): no list is asked until its Retry-After
// (APF's: 1 to 32 s) or LIST_SHED_FIRST_MS doubling on each shed in a row, whichever is longer, up to LIST_SHED_MAX_MS;
// meanwhile each list read answers the streak's cut at once, which every caller reads as unknown. Each list asks with
// `timeout=` a little under its budget (listTimeoutParam), so the API server stops a request no one waits for, and
// APF's queue holds it at most a quarter of that before it answers 429 rather than leave the budget to cut it. Any
// other failure (a token or CA that cannot be read, TLS, a connection refused, another status, a body that is no
// list), the in-process client unable to ask, is that one call sent to kubectl, said once until it changes. In a pod
// (KUBERNETES_SERVICE_HOST and _PORT set, no KUBECONFIG, the service-account token mounted: inClusterApiGet) it reads
// the token and CA from the mount on every call, since a projected token rotates. Node's https alone: no client
// library. Each shed answer counts on makefun_k8s_api_sheds_total{resource,code} (server/ops/metrics.ts), which the
// Capacity board and the k8s-api-sheds rule read.
//
// A `-o json` list is never parsed on the event loop: s18's pod lists run to megabytes, and a JSON.parse of one held a
// grader's and the worker's loop 60-80 ms, twice over (once here to see it is a list, once by the caller to read it).
// projectListBody, run on the off-thread pool (projectListTask, server/offthread), parses the body and hands back only
// the fields a caller reads (ListKeep: the caller's paths into each item), as a ListDoc. apiListExec keeps the doc it
// made with the result (listedDocOf), so the caller that asked under the same keep reads it with no second parse; any
// other list's stdout (kubectl's) is projected by its caller off the loop the same way (listDocOf). The pool saturated
// or failing is the list's cut (`error`), which every caller reads as unknown: never parsed on the loop instead.
//
// watchPod is a sandbox pod's boot read (the pod's IP, or why it will never have one) without a kubectl spawned: in a
// pod, one `watch=true` on the pod by fieldSelector `metadata.name` (the Role's `watch` on pods), over the same
// service-account token and CA as the lists (apiWatch, inClusterApiWatch), its events handed to the caller's verdict
// (`until`: an IP, a stopped container, no room; the driver's, so awaitPod's verdicts stand) and the request closed at
// once after one. A stream the server ends is watched on from its last resourceVersion; a 410 Gone re-lists (a watch
// with none, whose first events are the pod as it is). A shed watch, or any failure of the in-process client, is that
// call's `kubectl wait` instead, said once until it changes, a shed holding in-process watches off as a shed list
// does. Outside a pod (a burst grader's KUBECONFIG, the e2e rig, the tests) it is today's `kubectl wait`, as the lists
// are kubectl's there.
//
// apiCreate is a create asked in-process: a POST of an object's JSON (JSON_TYPE) into its collection, its answer handed
// back as it came. k8s.ts bootAgentPod makes a sandbox pod's `<pod>-env` Secret and then the pod so, over the same
// credentials as apiPatch below (inClusterApiCreate: the pod's own token, else a burst grader's kubeconfig), in place of
// a `kubectl create -f -` spawned for each pod (makefun-prod 2026-11-17: the grader's `created` phase 0.27-0.68 s mean,
// a Go binary started, its config and discovery read, for two POSTs of a few ms); the Role grants `create` on pods,
// secrets and networkpolicies already.
//
// apiPatch is the other write asked in-process: a merge patch (MERGE_PATCH_TYPE) of an object by its path, its answer
// handed back as it came. k8s.ts patchSecretOwner gives a pod's `<pod>-env` Secret its owner so, over the pod's own
// token (inClusterApiPatch), where `kubectl patch` would GET the Secret first: the Role grants secrets only create,
// delete and patch (a get returns the Secret's data), so kubectl's patch failed on every pod. A PATCH needs `patch`
// alone. A burst grader (KUBECONFIG, no service-account token: deploy/k8s/burst/grader-spec.ts) asks it the same
// way over its kubeconfig (kubeconfigApiTarget: the burst API, its CA and makefun-worker's token, read from the
// mounted file on every call, so a renewed token or a moved server is taken at once), as the burst kit's Role is
// create, delete and patch too. Anywhere else it is null and the driver's kubectl patch stands (a kubeconfig with no bearer token, as the
// e2e rig's admin one, a list of kubeconfigs, or one that is not JSON; the tests, which hand the driver a fake).

import { existsSync, readFileSync } from 'node:fs';
import { readFile } from 'node:fs/promises';
import type { IncomingMessage } from 'node:http';
import { Agent, request } from 'node:https';
import type { LookupFunction } from 'node:net';
import { join } from 'node:path';
import { StringDecoder } from 'node:string_decoder';
import { setTimeout as sleep } from 'node:timers/promises';
import { defineOffThreadTask, runOffThread } from '../../server/offthread/index.ts';
import type { KubectlCallOptions, KubectlExec, KubectlResult, PodJson } from './k8s.ts';

/** Where a pod's service-account token, CA and namespace are mounted. */
export const SERVICE_ACCOUNT_DIR = '/var/run/secrets/kubernetes.io/serviceaccount';

/** A list as a Table (meta.k8s.io/v1): one row per object, its cells the printer's columns, the name first. */
export const TABLE_ACCEPT = 'application/json;as=Table;g=meta.k8s.io;v=v1';
export const JSON_ACCEPT = 'application/json';

/** One answer of the API server: its status and its body. */
export interface ApiAnswer {
  status: number;
  body: string;
  /** Its Retry-After header, when it sent one (APF's 429 does: whole seconds). */
  retryAfter?: string;
}

/** The least wait after a shed list with no longer Retry-After: doubled for each shed in a row. */
export const LIST_SHED_FIRST_MS = 2_000;
/** The longest wait after a shed list, its Retry-After's included. */
export const LIST_SHED_MAX_MS = 60_000;

/** Whether an answer's status is a shed: 429, or any 5xx. */
export const isShed = (status: number): boolean => status === 429 || (status >= 500 && status <= 599);

/** A Retry-After header (delay-seconds or an HTTP-date) in ms from `now`, or 0 when absent or unreadable. */
export function retryAfterMs(value: string | undefined, now: number = Date.now()): number {
  if (value === undefined) return 0;
  const v = value.trim();
  if (/^\d+$/.test(v)) return Number(v) * 1000;
  const at = Date.parse(v);
  return Number.isNaN(at) ? 0 : Math.max(0, at - now);
}

/** The wait after the `streak`-th shed in a row (1 the first): its Retry-After or the doubled floor, the longer, capped. */
export function shedWaitMs(streak: number, retryAfter: number, first: number = LIST_SHED_FIRST_MS, max: number = LIST_SHED_MAX_MS): number {
  const floor = first * 2 ** Math.min(Math.max(0, streak - 1), 20);
  return Math.min(max, Math.max(retryAfter, floor));
}

/**
 * The `timeout` query value of a list asked within `budgetMs`: 90% of it in whole seconds, at least one. The API server
 * ends the request there (its request deadline), and APF's queue holds it at most a quarter of that.
 */
export function listTimeoutParam(budgetMs: number): string {
  return `${Math.max(1, Math.floor((budgetMs * 0.9) / 1000))}s`;
}

export interface ApiGetOptions {
  accept: string;
  /** No answer within it: an ApiCut. */
  timeoutMs: number;
  /** Aborting it cuts the request: an ApiCut. */
  signal?: AbortSignal;
}

/** A GET of `path` (with its query) on the API server; throws ApiCut when cut, any other Error when it could not be asked. */
export type ApiGet = (path: string, opts: ApiGetOptions) => Promise<ApiAnswer>;

/** A JSON merge patch's content type (RFC 7386; `kubectl patch --type=merge`'s). */
export const MERGE_PATCH_TYPE = 'application/merge-patch+json';

export interface ApiPatchOptions {
  /** No answer within it: an ApiCut. */
  timeoutMs: number;
  /** Aborting it cuts the request: an ApiCut. */
  signal?: AbortSignal;
}

/**
 * A merge patch (MERGE_PATCH_TYPE) of the object at `path` with `body` (its JSON), answered as JSON; throws ApiCut when
 * cut, any other Error when it could not be asked. Its answer is the caller's to read: any status, as it came.
 */
export type ApiPatch = (path: string, body: string, opts: ApiPatchOptions) => Promise<ApiAnswer>;

/** A JSON body's content type (a create's POST: k8s.ts bootAgentPod). */
export const JSON_TYPE = 'application/json';

/**
 * A create (POST) of the object `body` (its JSON) into the collection at `path` (with its query), answered as JSON;
 * throws ApiCut when cut, any other Error when it could not be asked. Its answer is the caller's to read: any status,
 * as it came.
 */
export type ApiCreate = (path: string, body: string, opts: ApiPatchOptions) => Promise<ApiAnswer>;

/** A request its budget or its signal cut: kubectl's SIGKILL, said the same way, and not asked again. */
export class ApiCut extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'ApiCut';
  }
}

/** The API server and the credentials apiGet reads per call. */
export interface ApiTarget {
  host: string;
  port: number;
  /** The bearer token's file, read on every call (unless `credentials` is given). */
  tokenFile: string;
  /** The CA bundle the server's certificate is checked against, read on every call (unless `credentials` is given). */
  caFile: string;
  /**
   * In place of the two files: the token, the CA and (where they moved) the server, read on every call
   * (kubeconfigApiTarget's, from a kubeconfig file).
   */
  credentials?: () => Promise<{ bearer: string; ca: string; host?: string; port?: number }>;
  /** How `host` resolves (default the system's); tests point a name at a local server. */
  lookup?: LookupFunction;
}

/**
 * GETs on `target`: the token and CA read fresh each call, over one keep-alive agent per CA (a new CA, a new agent),
 * the request destroyed at its budget or its signal.
 */
export function apiGet(target: ApiTarget): ApiGet {
  const ask = apiRequest(target);
  return (path, opts) => ask('GET', path, opts, null);
}

/** Merge patches on `target` (ApiPatch), each asked as apiGet asks: the token and CA read fresh, the budget and signal held. */
export function apiPatch(target: ApiTarget): ApiPatch {
  const ask = apiRequest(target);
  return (path, body, opts) => ask('PATCH', path, { accept: JSON_ACCEPT, ...opts }, { type: MERGE_PATCH_TYPE, body });
}

/** Creates on `target` (ApiCreate), each asked as apiGet asks: the token and CA read fresh, the budget and signal held. */
export function apiCreate(target: ApiTarget): ApiCreate {
  const ask = apiRequest(target);
  return (path, body, opts) => ask('POST', path, { accept: JSON_ACCEPT, ...opts }, { type: JSON_TYPE, body });
}

/** The token, the CA and the server a call on `target` asks with: its credentials', else its two files read now. */
async function targetCredentials(target: ApiTarget): Promise<{ bearer: string; ca: string; host: string; port: number }> {
  if (target.credentials !== undefined) {
    const c = await target.credentials();
    if (c.bearer.trim() === '') throw new Error('the API token is empty');
    return { bearer: c.bearer.trim(), ca: c.ca, host: c.host ?? target.host, port: c.port ?? target.port };
  }
  const [token, ca] = await Promise.all([readFile(target.tokenFile, 'utf8'), readFile(target.caFile, 'utf8')]);
  const bearer = token.trim();
  if (bearer === '') throw new Error(`the service-account token ${target.tokenFile} is empty`);
  return { bearer, ca, host: target.host, port: target.port };
}

/** One request on `target` (apiGet's, apiPatch's, apiCreate's), its body sent whole with its type and length. */
function apiRequest(target: ApiTarget): (method: 'GET' | 'PATCH' | 'POST', path: string, opts: ApiGetOptions, content: { type: string; body: string } | null) => Promise<ApiAnswer> {
  let held: { ca: string; agent: Agent } | null = null;
  return async (method, path, opts, content) => {
    if (opts.signal?.aborted === true) throw new ApiCut('cut off');
    const { bearer, ca, host, port } = await targetCredentials(target);
    if (held === null || held.ca !== ca) {
      held?.agent.destroy();
      held = { ca, agent: new Agent({ keepAlive: true, maxSockets: 4, ca }) };
    }
    const agent = held.agent;
    return new Promise<ApiAnswer>((resolve, reject) => {
      let cut: string | null = null;
      let settled = false;
      const timer = setTimeout(() => stop(`no answer within ${opts.timeoutMs} ms`), opts.timeoutMs);
      timer.unref();
      const onAbort = (): void => stop('cut off');
      const finish = (): boolean => {
        if (settled) return false;
        settled = true;
        clearTimeout(timer);
        opts.signal?.removeEventListener('abort', onAbort);
        return true;
      };
      const fail = (err: Error): void => {
        if (finish()) reject(cut === null ? err : new ApiCut(cut));
      };
      const req = request(
        {
          hostname: host,
          port,
          path,
          method,
          agent,
          headers: {
            accept: opts.accept,
            authorization: `Bearer ${bearer}`,
            ...(content === null ? {} : { 'content-type': content.type, 'content-length': String(Buffer.byteLength(content.body)) }),
          },
          ...(target.lookup === undefined ? {} : { lookup: target.lookup }),
        },
        (res) => {
          const chunks: Buffer[] = [];
          res.on('data', (b: Buffer) => chunks.push(b));
          res.on('error', fail);
          res.on('end', () => {
            const retryAfter = res.headers['retry-after'];
            if (finish()) resolve({ status: res.statusCode ?? 0, body: Buffer.concat(chunks).toString('utf8'), ...(typeof retryAfter === 'string' ? { retryAfter } : {}) });
          });
          res.on('close', () => {
            if (!res.complete) fail(new Error('the API server closed its answer before its end'));
          });
        },
      );
      function stop(why: string): void {
        cut ??= why;
        req.destroy(new Error(why));
      }
      req.on('error', fail);
      opts.signal?.addEventListener('abort', onAbort, { once: true });
      if (content === null) req.end();
      else req.end(content.body);
    });
  };
}

/**
 * The API server this process's pod reaches with its own service account, as kubectl's in-cluster config finds it:
 * KUBERNETES_SERVICE_HOST and KUBERNETES_SERVICE_PORT set, no KUBECONFIG (kubectl would read that instead), and the
 * token mounted in `dir`. Null anywhere else (a run from outside the cluster, the e2e rig, k3s from a shell).
 */
export function inClusterApiGet(env: NodeJS.ProcessEnv = process.env, dir: string = SERVICE_ACCOUNT_DIR): ApiGet | null {
  const target = inClusterApiTarget(env, dir);
  return target === null ? null : apiGet(target);
}

/**
 * The merge patches this process asks: with its pod's own service account (inClusterApiTarget), else with the bearer
 * token of its KUBECONFIG (kubeconfigApiTarget: a burst grader's), else null (the driver's kubectl patch).
 */
export function inClusterApiPatch(env: NodeJS.ProcessEnv = process.env, dir: string = SERVICE_ACCOUNT_DIR): ApiPatch | null {
  const target = inClusterApiTarget(env, dir) ?? kubeconfigApiTarget(env);
  return target === null ? null : apiPatch(target);
}

/**
 * The creates this process asks (k8s.ts bootAgentPod's Secret and pod): with its pod's own service account
 * (inClusterApiTarget), else with the bearer token of its KUBECONFIG (kubeconfigApiTarget: a burst grader's), else null
 * (the driver's `kubectl create -f -`).
 */
export function inClusterApiCreate(env: NodeJS.ProcessEnv = process.env, dir: string = SERVICE_ACCOUNT_DIR): ApiCreate | null {
  const target = inClusterApiTarget(env, dir) ?? kubeconfigApiTarget(env);
  return target === null ? null : apiCreate(target);
}

/** A kubeconfig's current context as kubeconfigApiTarget reads it: its server's host and port, its token and CA. */
interface KubeconfigCredentials {
  host: string;
  port: number;
  bearer: string;
  ca: string;
}

/**
 * The current context of a kubeconfig's text: an https:// server, its CA inline (certificate-authority-data) and a
 * bearer token inline (users[].user.token). Anything else (YAML that is not JSON, a client certificate, a CA file, no
 * context) is `{ why }`, saying which.
 */
export function kubeconfigCredentials(text: string): KubeconfigCredentials | { why: string } {
  let doc: {
    clusters?: { name?: unknown; cluster?: { server?: unknown; 'certificate-authority-data'?: unknown } }[];
    users?: { name?: unknown; user?: { token?: unknown } }[];
    contexts?: { name?: unknown; context?: { cluster?: unknown; user?: unknown } }[];
    'current-context'?: unknown;
  };
  try {
    doc = JSON.parse(text) as typeof doc;
  } catch {
    return { why: 'it is not JSON' };
  }
  if (doc === null || typeof doc !== 'object') return { why: 'it is no object' };
  const ctx = (Array.isArray(doc.contexts) ? doc.contexts : []).find((c) => c?.name === doc['current-context'])?.context;
  if (ctx === undefined) return { why: 'it has no current context' };
  const cluster = (Array.isArray(doc.clusters) ? doc.clusters : []).find((c) => c?.name === ctx.cluster)?.cluster;
  const user = (Array.isArray(doc.users) ? doc.users : []).find((u) => u?.name === ctx.user)?.user;
  let url: URL;
  try {
    url = new URL(String(cluster?.server));
  } catch {
    return { why: 'its server is no URL' };
  }
  if (url.protocol !== 'https:' || url.pathname.replace(/\/+$/, '') !== '') return { why: 'its server is no https:// API server' };
  const caData = cluster?.['certificate-authority-data'];
  if (typeof caData !== 'string' || caData === '') return { why: 'its cluster has no inline CA' };
  const token = user?.token;
  if (typeof token !== 'string' || token.trim() === '') return { why: 'its user has no bearer token' };
  return {
    host: url.hostname.replace(/^\[(.*)\]$/, '$1'),
    port: url.port === '' ? 443 : Number(url.port),
    bearer: token.trim(),
    ca: Buffer.from(caData, 'base64').toString('utf8'),
  };
}

/**
 * The API server and credentials of KUBECONFIG's current context (kubeconfigCredentials), read from the file on every
 * call: a burst grader's mounted Secret makefun-burst-kubeconfig, whose token `burst up`, extend and the autoscaler
 * renew in place. Null when KUBECONFIG is unset, names more than one file, or the file is missing or not such a kubeconfig now.
 */
export function kubeconfigApiTarget(env: NodeJS.ProcessEnv = process.env, o: { lookup?: LookupFunction } = {}): ApiTarget | null {
  const file = env.KUBECONFIG;
  if (file === undefined || file === '' || file.includes(':')) return null;
  let first: KubeconfigCredentials | { why: string };
  try {
    first = kubeconfigCredentials(readFileSync(file, 'utf8'));
  } catch {
    return null;
  }
  if ('why' in first) return null;
  return {
    host: first.host,
    port: first.port,
    tokenFile: file,
    caFile: file,
    credentials: async () => {
      const c = kubeconfigCredentials(await readFile(file, 'utf8'));
      if ('why' in c) throw new Error(`the kubeconfig ${file} cannot be asked with: ${c.why}`);
      return c;
    },
    ...(o.lookup === undefined ? {} : { lookup: o.lookup }),
  };
}

/** The API server and the service-account credentials inClusterApiGet, inClusterApiPatch, inClusterApiCreate and inClusterApiWatch ask with, or null outside a pod (a burst grader's patch and create: kubeconfigApiTarget). */
export function inClusterApiTarget(env: NodeJS.ProcessEnv = process.env, dir: string = SERVICE_ACCOUNT_DIR): ApiTarget | null {
  const host = env.KUBERNETES_SERVICE_HOST;
  const port = Number(env.KUBERNETES_SERVICE_PORT);
  if (host === undefined || host === '' || !Number.isInteger(port) || port <= 0 || port > 65_535) return null;
  if (env.KUBECONFIG !== undefined && env.KUBECONFIG !== '') return null;
  const tokenFile = join(dir, 'token');
  if (!existsSync(tokenFile)) return null;
  return { host, port, tokenFile, caFile: join(dir, 'ca.crt') };
}

/** One list read apiListExec answers: what it asks and how kubectl would print the answer. */
export interface ListRead {
  resource: 'pods' | 'nodes';
  path: string;
  accept: string;
  /** `-o name` (a Table, printed by `print`) or `-o json` (the server's list as it sent it, once projectListBody reads one). */
  output: 'name' | 'json';
  /** `-o name`'s lines (null: no list in it); null for `-o json`, whose list is read off the loop (projectListBody). */
  print: ((body: string) => string | null) | null;
}

const SINGULAR = { pods: 'pod', nodes: 'node' } as const;

/** `-o name` from a Table (cells[0] of each row), or from a plain list should the server answer one: `<kind>/<name>` lines. */
function printNames(kind: string, body: string): string | null {
  let doc: { kind?: unknown; rows?: unknown; items?: unknown };
  try {
    doc = JSON.parse(body) as typeof doc;
  } catch {
    return null;
  }
  let names: unknown[];
  if (doc?.kind === 'Table' && Array.isArray(doc.rows)) names = doc.rows.map((r: { cells?: unknown[] } | null) => r?.cells?.[0]);
  else if (Array.isArray(doc?.items)) names = doc.items.map((i: { metadata?: { name?: unknown } } | null) => i?.metadata?.name);
  else return null;
  if (!names.every((n): n is string => typeof n === 'string' && n !== '')) return null;
  return names.map((n) => `${kind}/${n}\n`).join('');
}

// ---------------------------------------------------------------- a JSON list, off the loop

/**
 * Paths into a listed object, one per field a caller reads: keys in order, `*` for each element of an array (its keys
 * then apply to every element). A path that ends keeps its value whole.
 */
export type ListKeep = readonly (readonly string[])[];

/**
 * A `-o json` list as projectListBody reads it: `parsed` false when the text is no JSON. Otherwise `doc` is the
 * parsed document cut to what a caller reads: `null` or a primitive as it was; an object as `{ items }` alone (absent
 * when the document has none), `items` an array of each item cut to `keep` (a field a path names copied where it is
 * present: an object or array descended into, anything else as it was), or, when it is no array, as it was. So
 * `doc?.items` and every `item?.a?.b` a path names read as they would on the whole document.
 */
export type ListDoc = { parsed: false } | { parsed: true; doc: unknown };

type KeepTrie = { [key: string]: KeepTrie } | null;

function keepTrie(keep: ListKeep): KeepTrie {
  const root: { [key: string]: KeepTrie } = {};
  let whole = false;
  for (const path of keep) {
    if (path.length === 0) whole = true;
    let at: { [key: string]: KeepTrie } = root;
    for (let i = 0; i < path.length; i++) {
      const key = path[i]!;
      const last = i === path.length - 1;
      const next = Object.hasOwn(at, key) ? at[key]! : undefined;
      if (last) {
        at[key] = null;
        break;
      }
      if (next === null) break; // a shorter path keeps it whole already
      at = at[key] = next ?? {};
    }
  }
  return whole ? null : root;
}

function project(value: unknown, trie: KeepTrie): unknown {
  if (trie === null || value === null || typeof value !== 'object') return value;
  const keys = Object.keys(trie);
  if (Object.hasOwn(trie, '*')) {
    if (!Array.isArray(value)) return value;
    const each = trie['*']!;
    return value.map((v) => project(v, each));
  }
  const src = value as Record<string, unknown>;
  const out: Record<string, unknown> = Array.isArray(value) ? ([] as unknown as Record<string, unknown>) : {};
  for (const key of keys) if (Object.hasOwn(src, key)) out[key] = project(src[key], trie[key]!);
  return out;
}

/** A `-o json` list's text read and cut to `keep` (ListDoc). Pure: the off-thread task projectListTask runs it. */
export function projectListBody(input: { body: string; keep: ListKeep }): ListDoc {
  let doc: unknown;
  try {
    doc = JSON.parse(input.body);
  } catch {
    return { parsed: false };
  }
  if (doc === null || typeof doc !== 'object') return { parsed: true, doc };
  if (!Object.hasOwn(doc, 'items')) return { parsed: true, doc: {} };
  const items = (doc as { items: unknown }).items;
  if (!Array.isArray(items)) return { parsed: true, doc: { items } };
  const trie = keepTrie(input.keep);
  return { parsed: true, doc: { items: items.map((item) => project(item, trie)) } };
}

/** projectListBody on the off-thread pool: a list's parse never holds the event loop. */
export const projectListTask = defineOffThreadTask<typeof projectListBody>('k8s.list-project', import.meta.url, 'projectListBody', { timeoutMs: 30_000 });

/** The ListDoc apiListExec made of a result's list, and the keep it was cut to. */
const listedDocs = new WeakMap<KubectlResult, { keep: ListKeep; doc: ListDoc }>();

/** The ListDoc apiListExec made of `result`'s list under `keep` (the same array), or null. */
export function listedDocOf(result: KubectlResult, keep: ListKeep): ListDoc | null {
  const kept = listedDocs.get(result);
  return kept !== undefined && kept.keep === keep ? kept.doc : null;
}

/**
 * `result`'s `-o json` stdout as a ListDoc cut to `keep`: apiListExec's own when it made one under that keep, else
 * projectListBody of it run off the loop. Rejects with the pool's OffThreadError when the pool cannot run it (the
 * caller reads the list as unknown), never parses on the loop.
 */
export async function listDocOf(result: KubectlResult, keep: ListKeep): Promise<ListDoc> {
  return listedDocOf(result, keep) ?? (await runOffThread(projectListTask, { body: result.stdout, keep }));
}

/** A list's items from a ListDoc as `(JSON.parse(stdout) as { items?: unknown } | null)?.items` reads them; undefined for a text that is no JSON. */
export function listItemsOf(listed: ListDoc): unknown {
  return listed.parsed ? (listed.doc as { items?: unknown } | null)?.items : undefined;
}

/**
 * The list read an argv asks for, or null for every argv apiListExec leaves to kubectl: `[-n|--namespace <ns>] get
 * pods|nodes` with only `--all-namespaces`/`-A`, `-l`/`--selector`, `--field-selector` (each as one word with `=` or
 * as two) and `-o`/`--output` name or json. Pods need a namespace or every one; nodes take neither.
 */
export function listRead(args: readonly string[]): ListRead | null {
  let i = 0;
  let namespace: string | null = null;
  if (args[0] === '-n' || args[0] === '--namespace') {
    namespace = args[1] ?? null;
    if (namespace === null || namespace === '') return null;
    i = 2;
  }
  if (args[i] !== 'get') return null;
  const resource = args[i + 1];
  if (resource !== 'pods' && resource !== 'nodes') return null;
  let all = false;
  let labels: string | null = null;
  let fields: string | null = null;
  let output: string | null = null;
  for (let j = i + 2; j < args.length; j++) {
    const a = args[j]!;
    const eq = a.indexOf('=');
    const flag = a.startsWith('--') && eq > 0 ? a.slice(0, eq) : a;
    const inline = flag === a ? null : a.slice(eq + 1);
    if (flag === '--all-namespaces' || flag === '-A') {
      if (inline !== null) return null;
      all = true;
      continue;
    }
    const value = inline ?? args[++j];
    if (value === undefined) return null;
    if (flag === '-l' || flag === '--selector') labels = value;
    else if (flag === '--field-selector') fields = value;
    else if (flag === '-o' || flag === '--output') output = value;
    else return null;
  }
  if (output !== 'name' && output !== 'json') return null;
  let base: string;
  if (resource === 'nodes') {
    if (namespace !== null || all) return null;
    base = '/api/v1/nodes';
  } else if (all) base = '/api/v1/pods';
  else if (namespace !== null) base = `/api/v1/namespaces/${encodeURIComponent(namespace)}/pods`;
  else return null;
  const query = new URLSearchParams();
  if (labels !== null && labels !== '') query.set('labelSelector', labels);
  if (fields !== null && fields !== '') query.set('fieldSelector', fields);
  if (output === 'name') query.set('includeObject', 'None');
  const q = query.toString();
  const kind = SINGULAR[resource];
  return {
    resource,
    path: q === '' ? base : `${base}?${q}`,
    accept: output === 'name' ? TABLE_ACCEPT : JSON_ACCEPT,
    output,
    print: output === 'name' ? (body) => printNames(kind, body) : null,
  };
}

/** A Status body's message (a refusal's words), else the body's first line. */
function statusMessage(body: string): string {
  try {
    const m = (JSON.parse(body) as { message?: unknown })?.message;
    if (typeof m === 'string' && m !== '') return m;
  } catch {
    // not a Status
  }
  return body.trim().split('\n')[0]?.slice(0, 300) ?? '';
}

export interface ApiListOptions {
  /** A call's budget when it names none (kubectlExec's: KUBECTL_TIMEOUT_MS). */
  timeoutMs: number;
  /** Where a fall back to kubectl, and a shed streak's start and end, are said, once until its reason changes. */
  warn: (line: string) => void;
  /** The clock a shed's wait is timed by (default Date.now). */
  now?: () => number;
  /**
   * What the callers of a `-o json` list read of each item, by resource (ListKeep): the doc apiListExec makes of the
   * list is cut to it and kept with the result (listedDocOf), so the caller reads it with no second parse. None: the
   * list is read whole by its caller (listDocOf), this read only seeing that it is one.
   */
  keep?: Partial<Record<ListRead['resource'], ListKeep>>;
}

/** The keep a list is checked under when its caller named none: nothing of an item. */
const NO_FIELDS: ListKeep = [];

/** A KubectlExec that answers the list reads listRead knows from `get` and hands everything else to `kubectl` (the header). */
export function apiListExec(get: ApiGet, kubectl: KubectlExec, opts: ApiListOptions): KubectlExec {
  const now = opts.now ?? Date.now;
  let said: string | null = null;
  // The open shed streak: how many in a row, the first one's words, and when a list is asked again.
  let shed: { streak: number; problem: string; until: number } | null = null;
  const shedCut = (resource: string, problem: string): KubectlResult => ({
    code: null,
    stdout: '',
    stderr: '',
    error: `kubectl get ${resource}: the API server shed the in-process lists (${problem}): none is asked until it may be again`,
  });
  return async (args, call = {}) => {
    const read = call.input === undefined ? listRead(args) : null;
    if (read === null) return kubectl(args, call);
    if (shed !== null && now() < shed.until) return shedCut(read.resource, shed.problem);
    const viaKubectl = (problem: string): Promise<KubectlResult> => {
      if (problem !== said) opts.warn(`k8s sandbox: the API server's list of ${read.resource} could not be read in-process (${problem}): kubectl reads it instead until it can`);
      said = problem;
      return kubectl(args, call);
    };
    const budget = call.timeoutMs ?? opts.timeoutMs;
    const path = `${read.path}${read.path.includes('?') ? '&' : '?'}timeout=${listTimeoutParam(budget)}`;
    let answer: ApiAnswer;
    try {
      answer = await get(path, { accept: read.accept, timeoutMs: budget, ...(call.signal === undefined ? {} : { signal: call.signal }) });
    } catch (err) {
      if (err instanceof ApiCut) return { code: null, stdout: '', stderr: '', error: `kubectl get ${read.resource}: ${err.message}` };
      return viaKubectl((err as Error).message);
    }
    if (isShed(answer.status)) {
      // makefun_k8s_api_sheds_total: every shed answer, where the line below says only a streak's first. Imported here,
      // not at the top: projectListTask's threads import this module, and the metrics module starts collectors at import.
      const { countK8sApiShed } = await import('../../server/ops/metrics.ts');
      countK8sApiShed(read.resource, answer.status);
      const problem = `HTTP ${answer.status}: ${statusMessage(answer.body)}`;
      const streak = (shed?.streak ?? 0) + 1;
      const wait = shedWaitMs(streak, retryAfterMs(answer.retryAfter, now()));
      if (shed === null) {
        opts.warn(
          `k8s sandbox: the API server shed the in-process list of ${read.resource} (${problem}${answer.retryAfter === undefined ? '' : `, Retry-After ${answer.retryAfter}`}): no list is asked of it for ${wait} ms, longer while it sheds, and each list read answers unknown meanwhile; kubectl is not asked instead`,
        );
      }
      shed = { streak, problem: shed?.problem ?? problem, until: now() + wait };
      return shedCut(read.resource, shed.problem);
    }
    const answered = (): void => {
      if (shed !== null) opts.warn(`k8s sandbox: the API server answers the in-process lists again, after ${shed.streak} shed in a row`);
      shed = null;
    };
    if (answer.status === 403) {
      answered();
      said = null;
      return { code: 1, stdout: '', stderr: `Error from server (Forbidden): ${statusMessage(answer.body)}\n` };
    }
    if (answer.status !== 200) return viaKubectl(`HTTP ${answer.status}: ${statusMessage(answer.body)}`);
    const noList = (): Promise<KubectlResult> => viaKubectl(`HTTP 200 with no list: ${JSON.stringify(answer.body.slice(0, 120))}`);
    if (read.print !== null) {
      const stdout = read.print(answer.body);
      if (stdout === null) return noList();
      answered();
      said = null;
      return { code: 0, stdout, stderr: '' };
    }
    // -o json: the body is the stdout as kubectl prints it, once the pool has read it as a list (and cut it to the keep)
    const keep = opts.keep?.[read.resource] ?? NO_FIELDS;
    let listed: ListDoc;
    try {
      listed = await runOffThread(projectListTask, { body: answer.body, keep }, call.signal === undefined ? {} : { signal: call.signal });
    } catch (err) {
      return { code: null, stdout: '', stderr: '', error: `kubectl get ${read.resource}: its list could not be read off the event loop (${(err as Error).message})` };
    }
    if (!Array.isArray(listItemsOf(listed))) return noList();
    answered();
    said = null;
    const result: KubectlResult = { code: 0, stdout: answer.body, stderr: '' };
    listedDocs.set(result, { keep, doc: listed });
    return result;
  };
}

// ---------------------------------------------------------------- a pod watched in-process

/** One watch's answer: its status, and a 200's events as they arrive (a non-200's body read whole). */
export interface ApiWatchAnswer {
  status: number;
  /** A non-200's body ('' for a 200, whose body is `lines`). */
  body: string;
  /** Its Retry-After header, when it sent one. */
  retryAfter?: string;
  /** A 200's events, one line of JSON each, until the server ends the stream; throws ApiCut once the signal cuts it. */
  lines: AsyncIterable<string>;
  /** Ends the request at once, its socket destroyed: nothing more is read of it. */
  close(): void;
}

export interface ApiWatchOptions {
  /** No answer's head within it: an ApiCut. The stream after the head stays open until close(), the signal or the server's end. */
  timeoutMs: number;
  /** Aborting it cuts the request, the stream too: an ApiCut. */
  signal?: AbortSignal;
}

/** A streamed GET of `path` (a `watch=true` query) on the API server; throws ApiCut when cut, any other Error when it could not be asked. */
export type ApiWatch = (path: string, opts: ApiWatchOptions) => Promise<ApiWatchAnswer>;

const NO_LINES: AsyncIterable<string> = { [Symbol.asyncIterator]: async function* () {} };

/** `res`'s body cut at each newline, blank lines dropped; a cut of the request thrown as ApiCut, an unfinished body as an Error. */
async function* streamLines(res: IncomingMessage, cutOf: () => string | null, end: () => void): AsyncGenerator<string> {
  const decoder = new StringDecoder('utf8');
  let rest = '';
  try {
    try {
      for await (const chunk of res as AsyncIterable<Buffer>) {
        rest += decoder.write(chunk);
        for (let i = rest.indexOf('\n'); i >= 0; i = rest.indexOf('\n')) {
          const line = rest.slice(0, i).trim();
          rest = rest.slice(i + 1);
          if (line !== '') yield line;
        }
      }
    } catch (err) {
      const cut = cutOf();
      throw cut === null ? err : new ApiCut(cut);
    }
    const cut = cutOf();
    if (cut !== null) throw new ApiCut(cut);
    if (!res.complete) throw new Error('the API server closed the watch before its end');
    const last = (rest + decoder.end()).trim();
    if (last !== '') yield last;
  } finally {
    end();
  }
}

/**
 * Streamed GETs on `target` (a watch): the token and CA read fresh each call as apiGet's are, over an agent per CA that
 * keeps no socket (a watch is closed by destroying it), the request destroyed when its head is late, its signal aborts
 * or the caller closes it.
 */
export function apiWatch(target: ApiTarget): ApiWatch {
  let held: { ca: string; agent: Agent } | null = null;
  return async (path, opts) => {
    if (opts.signal?.aborted === true) throw new ApiCut('cut off');
    const { bearer, ca, host, port } = await targetCredentials(target);
    if (held === null || held.ca !== ca) {
      held?.agent.destroy();
      held = { ca, agent: new Agent({ keepAlive: false, ca }) };
    }
    const agent = held.agent;
    return new Promise<ApiWatchAnswer>((resolve, reject) => {
      let cut: string | null = null;
      let headed = false;
      let ended = false;
      const timer = setTimeout(() => stop(`no answer within ${opts.timeoutMs} ms`), opts.timeoutMs);
      timer.unref();
      const onAbort = (): void => stop('cut off');
      const end = (): void => {
        if (ended) return;
        ended = true;
        clearTimeout(timer);
        opts.signal?.removeEventListener('abort', onAbort);
      };
      const close = (): void => {
        stop('closed');
        end();
      };
      const req = request(
        {
          hostname: host,
          port,
          path,
          method: 'GET',
          agent,
          headers: { accept: JSON_ACCEPT, authorization: `Bearer ${bearer}` },
          ...(target.lookup === undefined ? {} : { lookup: target.lookup }),
        },
        (res) => {
          clearTimeout(timer);
          res.on('error', () => undefined); // what a cut stream throws reaches its reader; none read, it is dropped
          const status = res.statusCode ?? 0;
          const retryAfter = res.headers['retry-after'];
          const head = { status, ...(typeof retryAfter === 'string' ? { retryAfter } : {}) };
          if (status === 200) {
            headed = true;
            resolve({ ...head, body: '', lines: streamLines(res, () => cut, end), close });
            return;
          }
          const chunks: Buffer[] = [];
          res.on('data', (b: Buffer) => chunks.push(b));
          res.on('end', () => {
            if (headed) return;
            headed = true;
            end();
            resolve({ ...head, body: Buffer.concat(chunks).toString('utf8'), lines: NO_LINES, close });
          });
          res.on('close', () => {
            if (!res.complete) fail(new Error('the API server closed its answer before its end'));
          });
        },
      );
      function fail(err: Error): void {
        if (headed) return;
        headed = true;
        end();
        reject(cut === null ? err : new ApiCut(cut));
      }
      function stop(why: string): void {
        cut ??= why;
        req.destroy(new Error(why));
      }
      req.on('error', fail);
      opts.signal?.addEventListener('abort', onAbort, { once: true });
      req.end();
    });
  };
}

/** The watch this process's pod asks with its own service account (inClusterApiTarget), or null outside a pod: watchPod's kubectl wait. */
export function inClusterApiWatch(env: NodeJS.ProcessEnv = process.env, dir: string = SERVICE_ACCOUNT_DIR): ApiWatch | null {
  const target = inClusterApiTarget(env, dir);
  return target === null ? null : apiWatch(target);
}

/** What watchPod needs of the driver's K8sContext (which has each field), and the watch it asks in a pod. */
export interface PodWatchContext {
  namespace: string;
  /** kubectl, for the wait outside a pod (each argv led by `-n <namespace>`, as kubectl() sends it). */
  exec: KubectlExec;
  /** Where a fall back to kubectl, and a shed watch, are said, once until the reason changes. */
  warn: (line: string) => void;
  /** The pace the kubectl calls are shown to, as kubectl() shows an unpaced verb's (a fault it names cuts the pace). */
  pace?: { readonly epoch: number; observe(r: KubectlResult, startedAt: number): void } | null;
  /** The API server's watch, in a pod (inClusterApiWatch); absent or null: kubectl wait. */
  apiWatch?: ApiWatch | null;
}

/** A pod as a watch event or `kubectl get pod -o json` carries it: PodJson, with the name and resourceVersion the watch reads. */
export type WatchedPod = PodJson & { metadata?: { name?: string; resourceVersion?: string } };

/** What watchPod waits on: its verdict over a pod read (an IP, a stopped container, no room: the caller's), or null/undefined to wait on. */
export type PodUntil<T> = (pod: WatchedPod) => T | null | undefined;

/**
 * How watchPod ended: `until`'s verdict over `pod`, the read it answered; the pod deleted or not found (`gone`); or the
 * signal's cut, with the last read of the pod (null: none seen) and, when the last try to read it failed, why (`unread`).
 */
export type PodWatchEnd<T> =
  | { verdict: T; pod: WatchedPod }
  | { gone: string; last: WatchedPod | null }
  | { cut: true; last: WatchedPod | null; unread?: string };

/** The jsonpath watchPod's kubectl wait reads by default: met once the pod has an IP. */
export const POD_IP_JSONPATH = '{.status.podIP}';
/** How long a watch has for its answer's head before kubectl stands in for it. */
export const WATCH_ANSWER_MS = 10_000;
/** One kubectl wait's slice, in seconds, outside a pod: the pod is read and `until` asked between two (awaitPod's WAIT_SLICE_S). */
export const WATCH_WAIT_SLICE_S = 5;
/** The least time between two reads of the pod outside a pod (awaitPod's WAIT_PAUSE_MS). */
export const WATCH_PAUSE_MS = 500;
/** How many watches in a row may end with no event before kubectl stands in for them. */
export const WATCH_EMPTY_ENDS = 2;

export interface WatchPodOptions {
  /** kubectl wait's `--for` outside a pod (default `jsonpath=POD_IP_JSONPATH`). */
  waitFor?: string;
  /** Default WATCH_WAIT_SLICE_S. */
  sliceS?: number;
  /** Default WATCH_PAUSE_MS. */
  pauseMs?: number;
  /** Default WATCH_ANSWER_MS. */
  answerMs?: number;
  /** The clock a shed's hold is timed by (default Date.now). */
  now?: () => number;
}

/** Per watch: the fall back last said (said once until it changes), and the shed streak holding in-process watches off. */
const watchStates = new WeakMap<ApiWatch, { said: string | null; shed: { streak: number; until: number } | null }>();

/** kubectl's words for a call that failed (k8s.ts why's, kept here: this module imports no value of the driver). */
function kubectlSaid(r: KubectlResult): string {
  const said = r.stderr
    .split('\n')
    .map((l) => l.trim())
    .find((l) => l !== '' && !l.startsWith('Warning:'));
  return r.error ?? said ?? (r.code === null ? 'no answer' : `exit ${r.code}`);
}

/** How the in-process watch ended: watchPod's end, or why kubectl waits instead (`heldMs`: a shed, in-process watches held off that long). */
type InProcessEnd<T> = { end: PodWatchEnd<T> } | { fallback: string; heldMs?: number };

/**
 * Wait on pod `name` until `until` gives a verdict over it, `signal` cuts the wait, or the pod is gone. In a pod
 * (ctx.apiWatch): one `watch=true` on the pod by fieldSelector `metadata.name` with no resourceVersion, whose first
 * events are the pod as it is (the API server's state, then each change), each handed to `until`; the request closed
 * at once after a verdict. A stream the server ends is watched again from the last resourceVersion seen (bookmarks
 * asked); a 410 Gone (its status or an ERROR event: that version is compacted away) re-lists, a watch again with none.
 * A shed (429, any 5xx) is counted (makefun_k8s_api_sheds_total), said once and holds in-process watches off for its
 * Retry-After or the doubled floor (shedWaitMs), and that call, like any other failure (a token or CA unreadable, TLS,
 * another status, an event that is no JSON, WATCH_EMPTY_ENDS streams in a row with no event), waits by kubectl for
 * the rest. Outside a pod, today's `kubectl wait --for=<waitFor> pod/<name>` in slices, the pod read and `until` asked
 * after each.
 */
export async function watchPod<T>(ctx: PodWatchContext, name: string, until: PodUntil<T>, signal?: AbortSignal, opts: WatchPodOptions = {}): Promise<PodWatchEnd<T>> {
  const watch = ctx.apiWatch ?? null;
  const seen: { last: WatchedPod | null } = { last: null };
  if (watch !== null) {
    const now = opts.now ?? Date.now;
    let state = watchStates.get(watch);
    if (state === undefined) watchStates.set(watch, (state = { said: null, shed: null }));
    if (state.shed === null || now() >= state.shed.until) {
      const r = await watchInProcess(watch, ctx, name, until, signal, opts, seen, state);
      if ('end' in r) {
        if (!('cut' in r.end)) state.said = null;
        return r.end;
      }
      if (r.fallback !== state.said) {
        ctx.warn(
          r.heldMs === undefined
            ? `k8s sandbox: the API server's watch of pod ${name} could not be read in-process (${r.fallback}): kubectl wait stands in for it until it can`
            : `k8s sandbox: the API server shed the in-process watch of pod ${name} (${r.fallback}): kubectl wait stands in for it, and for every pod watch of the next ${r.heldMs} ms, longer while it sheds`,
        );
      }
      state.said = r.fallback;
    }
  }
  return waitByKubectl(ctx, name, until, signal, opts, seen.last);
}

/** Whether `signal` has aborted (a call, not a property read TypeScript narrows across an await). */
const aborted = (signal: AbortSignal | undefined): boolean => signal?.aborted === true;

async function watchInProcess<T>(
  watch: ApiWatch,
  ctx: PodWatchContext,
  name: string,
  until: PodUntil<T>,
  signal: AbortSignal | undefined,
  opts: WatchPodOptions,
  seen: { last: WatchedPod | null },
  state: { shed: { streak: number; until: number } | null },
): Promise<InProcessEnd<T>> {
  const now = opts.now ?? Date.now;
  const cutEnd = (): InProcessEnd<T> => ({ end: { cut: true, last: seen.last } });
  const shedFallback = async (status: number, problem: string, retryAfter: string | undefined): Promise<InProcessEnd<T>> => {
    // Imported here, not at the top, as apiListExec's count is: projectListTask's threads import this module.
    const { countK8sApiShed } = await import('../../server/ops/metrics.ts');
    countK8sApiShed('pods', status);
    const streak = (state.shed?.streak ?? 0) + 1;
    const heldMs = shedWaitMs(streak, retryAfterMs(retryAfter, now()));
    state.shed = { streak, until: now() + heldMs };
    return { fallback: problem, heldMs };
  };
  let version: string | null = null;
  let empty = 0;
  for (;;) {
    if (aborted(signal)) return cutEnd();
    const query = new URLSearchParams({ fieldSelector: `metadata.name=${name}`, watch: 'true', allowWatchBookmarks: 'true' });
    if (version !== null) query.set('resourceVersion', version);
    let answer: ApiWatchAnswer;
    try {
      answer = await watch(`/api/v1/namespaces/${encodeURIComponent(ctx.namespace)}/pods?${query}`, {
        timeoutMs: opts.answerMs ?? WATCH_ANSWER_MS,
        ...(signal === undefined ? {} : { signal }),
      });
    } catch (err) {
      if (aborted(signal)) return cutEnd();
      return { fallback: (err as Error).message };
    }
    try {
      if (answer.status === 410 && version !== null) {
        version = null; // re-list
        continue;
      }
      if (isShed(answer.status)) return await shedFallback(answer.status, `HTTP ${answer.status}: ${statusMessage(answer.body)}`, answer.retryAfter);
      if (answer.status !== 200) return { fallback: `HTTP ${answer.status}: ${statusMessage(answer.body)}` };
      state.shed = null;
      let events = 0;
      let relist = false;
      try {
        for await (const line of answer.lines) {
          events++;
          let event: { type?: unknown; object?: unknown };
          try {
            event = JSON.parse(line) as typeof event;
          } catch {
            return { fallback: `a watch event that is no JSON: ${JSON.stringify(line.slice(0, 120))}` };
          }
          const object = (event?.object ?? null) as (WatchedPod & { code?: unknown; message?: unknown }) | null;
          if (event?.type === 'ERROR') {
            const code = typeof object?.code === 'number' ? object.code : 0;
            const message = typeof object?.message === 'string' ? object.message : 'no message';
            if (code === 410 && version !== null) {
              relist = true;
              break;
            }
            if (isShed(code)) return await shedFallback(code, `an ERROR event ${code}: ${message}`, undefined);
            return { fallback: `an ERROR event ${code}: ${message}` };
          }
          if (object === null || typeof object !== 'object') continue;
          const rv = object.metadata?.resourceVersion;
          if (typeof rv === 'string' && rv !== '') version = rv;
          if (event.type === 'BOOKMARK' || object.metadata?.name !== name) continue;
          if (event.type === 'DELETED') return { end: { gone: `pod ${name} was deleted`, last: seen.last ?? object } };
          if (event.type !== 'ADDED' && event.type !== 'MODIFIED') continue;
          seen.last = object;
          const verdict = until(object);
          if (verdict !== null && verdict !== undefined) return { end: { verdict, pod: object } };
        }
      } catch (err) {
        if (aborted(signal) || err instanceof ApiCut) return cutEnd();
        return { fallback: (err as Error).message };
      }
      if (relist) {
        version = null;
        empty = 0;
        continue;
      }
      empty = events === 0 ? empty + 1 : 0;
      if (empty >= WATCH_EMPTY_ENDS) return { fallback: `${empty} watches in a row ended with no event` };
    } finally {
      answer.close();
    }
  }
}

/** watchPod outside a pod (or after the watch failed): `kubectl wait` slices, the pod read and `until` asked after each. */
async function waitByKubectl<T>(ctx: PodWatchContext, name: string, until: PodUntil<T>, signal: AbortSignal | undefined, opts: WatchPodOptions, seen: WatchedPod | null): Promise<PodWatchEnd<T>> {
  const sliceS = Math.max(1, Math.floor(opts.sliceS ?? WATCH_WAIT_SLICE_S));
  const pauseMs = opts.pauseMs ?? WATCH_PAUSE_MS;
  const waitFor = `--for=${opts.waitFor ?? `jsonpath=${POD_IP_JSONPATH}`}`;
  const sig = signal === undefined ? {} : { signal };
  const run = async (args: readonly string[], call: KubectlCallOptions): Promise<KubectlResult> => {
    const pace = ctx.pace ?? null;
    const startedAt = pace?.epoch ?? 0;
    const r = await ctx.exec(['-n', ctx.namespace, ...args], call);
    pace?.observe(r, startedAt);
    return r;
  };
  let last = seen;
  let unread: string | undefined;
  const cut = (): PodWatchEnd<T> => ({ cut: true, last, ...(unread === undefined ? {} : { unread }) });
  for (;;) {
    if (aborted(signal)) return cut();
    const started = Date.now();
    await run(['wait', waitFor, `pod/${name}`, `--timeout=${sliceS}s`], { ...sig, timeoutMs: (sliceS + 30) * 1000 });
    if (aborted(signal)) return cut();
    const r = await run(['get', `pod/${name}`, '-o', 'json'], sig);
    if (aborted(signal)) return cut();
    if (r.code === 0 && r.error === undefined) {
      let pod: unknown = null;
      try {
        pod = JSON.parse(r.stdout);
      } catch {
        // said below
      }
      if (pod === null || typeof pod !== 'object') unread = 'kubectl get printed no pod';
      else {
        last = pod as WatchedPod;
        unread = undefined;
        const verdict = until(last);
        if (verdict !== null && verdict !== undefined) return { verdict, pod: last };
      }
    } else if (/\(NotFound\)|not found/i.test(r.stderr)) return { gone: kubectlSaid(r), last };
    else unread = kubectlSaid(r);
    const pause = pauseMs - (Date.now() - started);
    if (pause > 0) {
      try {
        await sleep(pause, undefined, sig);
      } catch {
        return cut();
      }
    }
  }
}
